"""
TFS AgentCore Runtime Server
Unified FastAPI server with /invoke endpoint for Amazon Bedrock AgentCore
"""
import os
import asyncio
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn

# Import configuration and master agent
from config.env_loader import load_environment
from agents.master_agent import MasterAgent


# ==================== REQUEST MODELS ====================
class InvokeRequest(BaseModel):
    """
    AgentCore invoke request model
    Compatible with Amazon Bedrock AgentCore runtime specification
    """
    inputText: str
    sessionId: str = None
    attributes: dict = {}


class InvokeResponse(BaseModel):
    """
    AgentCore invoke response model
    """
    outputText: str
    sessionId: str = None
    attributes: dict = {}


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    service: str
    version: str


# ==================== FASTAPI APP ====================
app = FastAPI(
    title="TFS AgentCore Runtime",
    description="Toyota Financial Services Multi-Agent System for Amazon Bedrock AgentCore",
    version="1.0.0"
)

# Global master agent instance
master_agent = None


# ==================== INITIALIZATION ====================
@app.on_event("startup")
async def startup_event():
    """Initialize the master agent and configuration"""
    global master_agent
    
    try:
        # Load environment configuration
        config = load_environment()
        print(f"Environment loaded successfully")
        print(f"AWS Region: {config['AWS_REGION']}")
        print(f"Bedrock Model: {config['BEDROCK_MODEL_ID']}")
        print(f"Knowledge Base: {config['KNOWLEDGE_BASE_ID']}")
        
        # Initialize master agent
        master_agent = MasterAgent(config)
        print("Master agent initialized successfully")
        print("TFS AgentCore Runtime is ready")
        
    except Exception as e:
        print(f"Startup failed: {str(e)}")
        raise


# ==================== AGENTCORE ENDPOINT ====================
@app.post("/invoke", response_model=InvokeResponse)
async def invoke_handler(request: InvokeRequest):
    """
    Main AgentCore invoke endpoint
    Processes user queries through the TFS multi-agent system
    
    Args:
        request: AgentCore invoke request with inputText
        
    Returns:
        AgentCore-compatible response with outputText
    """
    if not master_agent:
        raise HTTPException(
            status_code=503,
            detail="Service not initialized"
        )
    
    try:
        # Process query through master agent
        result = await master_agent.process_query(request.inputText)
        print(f"[DEBUG] Master agent result: {result}")
        
        # Extract response text
        if "answer" in result:
            output_text = result["answer"]
            print(f"[DEBUG] Using answer field: {output_text[:100]}...")
        elif "error" in result:
            output_text = f"Error: {result['error']}"
            print(f"[DEBUG] Using error field: {output_text}")
        else:
            output_text = "Request processed but no response generated."
            print(f"[DEBUG] No answer or error field, using default. Result keys: {list(result.keys())}")
        
        # Return AgentCore-compatible response
        return InvokeResponse(
            outputText=output_text,
            sessionId=request.sessionId or "",
            attributes=request.attributes
        )
        
    except Exception as e:
        # Log error and return AgentCore-compatible error response
        print(f"Invoke error: {str(e)}")
        return InvokeResponse(
            outputText=f"I'm sorry, I encountered an error processing your request: {str(e)}",
            sessionId=request.sessionId or "",
            attributes=request.attributes
        )


# ==================== HEALTH ENDPOINT ====================
@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint for monitoring"""
    return HealthResponse(
        status="healthy" if master_agent else "unhealthy",
        service="tfs-agentcore-runtime",
        version="1.0.0"
    )


# ==================== LEGACY ENDPOINTS ====================
@app.get("/")
async def root():
    """Root endpoint with service information"""
    return {
        "service": "TFS AgentCore Runtime",
        "version": "1.0.0",
        "description": "Toyota Financial Services Multi-Agent System for Amazon Bedrock AgentCore",
        "endpoints": {
            "invoke": "/invoke (POST) - Main AgentCore endpoint",
            "health": "/health (GET) - Health check",
            "root": "/ (GET) - Service information"
        },
        "status": "ready" if master_agent else "initializing"
    }


@app.post("/query")
async def legacy_query(query_request: dict):
    """
    Legacy query endpoint for backward compatibility
    Maps to the new /invoke endpoint
    """
    # Convert legacy request to AgentCore format
    invoke_request = InvokeRequest(
        inputText=query_request.get("query", ""),
        sessionId=query_request.get("session_id"),
        attributes=query_request.get("attributes", {})
    )
    
    # Process through invoke endpoint
    response = await invoke_handler(invoke_request)
    
    # Convert back to legacy format
    return {
        "answer": response.outputText,
        "session_id": response.sessionId or "",
        "attributes": response.attributes
    }


# ==================== START SERVER ====================
if __name__ == "__main__":
    import sys
    
    # Check for port argument
    port = 8080  # Default port for AgentCore runtime
    if len(sys.argv) > 1 and "--port" in sys.argv:
        port_index = sys.argv.index("--port") + 1
        if port_index < len(sys.argv):
            port = int(sys.argv[port_index])
    
    # Check for host argument
    host = "0.0.0.0"
    if len(sys.argv) > 1 and "--host" in sys.argv:
        host_index = sys.argv.index("--host") + 1
        if host_index < len(sys.argv):
            host = sys.argv[host_index]
    
    print(f"Starting TFS AgentCore Runtime on {host}:{port}")
    print(f"AgentCore invoke endpoint: http://{host}:{port}/invoke")
    print(f"Health check: http://{host}:{port}/health")
    
    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level="info"
    )
